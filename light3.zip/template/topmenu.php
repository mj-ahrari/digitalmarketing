 <div id="topmenu">
 <?php
 //include_once('class/category.php');
 //$category = new category();
// $rescategory=$category->select();
// while($rowcategory=$rescategory->fetch(PDO::FETCH_ASSOC))
// {
 ?>
        	<!--<div class="topmenu-li">
            	<div class="topmenu-li-top"><a href="category.php?cid=<?php //echo $rowcategory['cid']?>"><?php //echo $rowcategory['title']?></a></div> <div class="topmenu-li-bottom"></div>
            </div>-->
            <?php
 //}
			?>
            <div class="topmenu-li">
            	<div class="topmenu-li-top" ><a href="index.php">فروشگاه</a></div> <div class="topmenu-li-bottom"></div>
            </div> 
			<div class="topmenu-li">
            	<div class="topmenu-li-top" ><a href="traning.php">دوره های آموزشی</a></div> <div class="topmenu-li-bottom"></div>
            </div> 
			<div class="topmenu-li">
            	<div class="topmenu-li-top" ><a href="magazine.php">مجله زیبایی</a></div> <div class="topmenu-li-bottom"></div>
            </div> 
			<div class="topmenu-li">
            	<div class="topmenu-li-top" ><a href="tejarat.php">بازرگانی</a></div> <div class="topmenu-li-bottom"></div>
            </div> 
            <!--<div class="topmenu-li">
            	<div class="topmenu-li-top" style="background-color:#222"><a href="special.php">فروش ویژه</a></div> <div class="topmenu-li-bottom"></div>
            </div>-->
        </div><!--End of topmenu-->