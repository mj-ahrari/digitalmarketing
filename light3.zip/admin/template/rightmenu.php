<div class="nav">
    	<ul>
        	<li class="active">
            	<div class="fix">
                    <span class="ico"><img src="image/ico1.png"></span>
                    <span class="value">مدیریت</span>
                </div>
             </li>
            <li>
            	<div class="fix">
                    <span class="ico"><img src="image/ico2.png"></span>
                    <span class="value">بخش کاربران</span>
                </div>
                <ul>
                    <li><a href="users.php">مدیریت کاربران</a></li>
                </ul>
            </li>
			<li>
            	<div class="fix">
                    <span class="ico"><img src="image/ico2.png"></span>
                    <span class="value">بخش مدرسین</span>
                </div>
                <ul>
                    <li><a href="modareslist.php">لیست مدرسین</a></li>
					<li><a href="insertmodares.php">افزودن مدرس</a></li>
                    <li><a href="modaressetting.php">تغییر هدر صفحه اساتید</a></li>
                </ul>
            </li>
			<li>
            	<div class="fix">
                    <span class="ico"><img src="image/ico3.png"></span>
                    <span class="value">بخش دوره ها</span>
                </div>
                <ul>
                    <li><a href="courselist.php">لیست دوره ها</a></li>
					<li><a href="insertcourse.php">افزودن دوره</a></li>
                </ul>
            </li>
            <li>
            <div class="fix">
                <span class="ico"><img src="image/ico3.png"></span>
                <span class="value">مدیریت محصولات </span>
            </div>
                <ul>
                	<li><a href="productlist.php">لیست محصولات</a></li>
                    <li><a href="insertproduct.php">ایجاد محصول جدید</a></li>
                </ul>
            </li>
            <li>
            <div class="fix">
                <span class="ico"><img src="image/ico4.png"></span>
                <span class="value">مدیریت دسته ها</span>
            </div>
                <ul>
                	<li><a href="category.php">مدیریت دسته</a></li>
                </ul>
            </li>
			<li>
            <div class="fix">
                <span class="ico"><img src="image/ico4.png"></span>
                <span class="value">مدیریت پیام ها</span>
            </div>
                <ul>
                	<li><a href="messages.php">پیام ها</a></li>
                </ul>
            </li>
            <li>
            <div class="fix">
                <span class="ico"><img src="image/ico4.png"></span>
                <span class="value">مدیریت برندها</span>
            </div>
                <ul>
                	<li><a href="brand.php">مدیریت برندها</a></li>
                </ul>
            </li>
           <li>
            <div class="fix">
                <span class="ico"><img src="image/ico4.png"></span>
                <span class="value">مدیریت اسلایدر و لوگو</span>
            </div>
                <ul>
                	<li><a href="slider.php">مدیریت اسلایدر</a></li>
                    <li><a href="logo.php">مدیریت لوگو</a></li>
                </ul>
            </li>
            <li>
            <div class="fix">
                <span class="ico"><img src="image/ico4.png"></span>
                <span class="value">مدیریت سفارشات</span>
            </div>
                <ul>
                	<li><a href="orderlist.php">لیست سفارشات</a></li>
                </ul>
            </li>
            <li>
            	<div class="fix">
                    <span class="ico"><img src="image/ico4.png"></span>
                    <span class="value">مدیریت شعبات</span>
                </div>
                <ul>
                    <li><a href="insertbranch.php">افزودن شعبه</a></li>
                    <li><a href="branchlist.php">لیست شعبات</a></li>
                    <li><a href="branchsetting.php">تنظیمات (تغییر هدر و فوتر این صفحه)</a></li>
                </ul>
            </li>
            <li>
            	<div class="fix">
                    <span class="ico"><img src="image/ico4.png"></span>
                    <span class="value">مدیریت مجله ها</span>
                </div>
                <ul>
                    <li><a href="insertmagazine.php">افزودن مجله</a></li>
                    <li><a href="magazinelist.php">لیست مجله ها</a></li>
                </ul>
            </li>
        </ul>
    </div>