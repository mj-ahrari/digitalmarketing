<ul data-collapse="collapse" class="quick">
        <li>
            <a href="../index.php">
                <img alt="" src="image/statistics.png">
                <span>صفحه اصلی</span>
            </a>
        </li>
        <li>
            <a href="setting.php">
                <img alt="" src="image/lock.png">
                <span>تنظیمات کلی</span>
            </a>
        </li>
  	    <li>
            <a href="password.php">
                <img alt="" src="image/my-account.png">
                <span>مدیریت پسورد</span>
            </a>
        </li>
        <li>
            <a href="logout.php?logout=logout">
                <img alt="" src="image/refresh.png">
                <span>خروج</span>
            </a>
        </li>
    </ul>